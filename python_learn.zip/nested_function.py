# function calls inside another function call
# print an absolute whole positive number

print(round(abs(float(input("enter a whole positive number: ")))))
