# while loop is a statement that will execute its block of code as long as its condition remains true
name = str(input("your name : "))
while name != "bro":
    name = input("your name: ")
