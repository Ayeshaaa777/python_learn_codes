'''for j in range(2):
    for i in range(3):
        print("hi", end="")
print()'''

'''n = int(input().strip())
if n % 2 != 0:
    print("Weird")
else:
    if n >= 2 and n <= 5:
        print("Not weird")
    elif n >= 6 and n <= 20:
        print("Weird")
    elif n > 20:
        print("Not Weird")'''

'''number = int(input("enter a number : "))
flag = 0
for i in range(2, number//2 + 1):
    if (number % i == 0):
        print("not a prime")
        flag = 1
        break
if (flag == 0):
    print("number is a prime")'''

'''import random as r
A = [10, 200, 13, 44, 56, 36, 97, 808, 990, 120]

print(r.sample(A, 10))'''
