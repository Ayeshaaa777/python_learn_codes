# type casting - convert the data type of a value to another data type
x = 1
y = 2.0
z = "3"  # str also u cannot add strings
x = float(x)
y = float(y)
z = float(z)
print("x is "+str(x))  # concatenate
print(y)
print(z)
print(z*3)
