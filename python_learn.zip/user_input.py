name = input("What is your name?: ")
age = int(input("how old are you?: "))
height = float(input("how tall are you?: "))
# can only concatenate string with string
age = age+1
print("hello" + name)
print("You are "+str(age)+"years old")
print("You are "+str(height)+"cm tall")
