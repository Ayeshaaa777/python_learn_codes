# 2d lists = a list of lists
drinks = ["coffee", "soda", "tea"]
dinner = ["pizza", "hamburger", "hotdog"]
dessert = ["cake", "ice cream"]
food = [drinks, dinner, dessert]

print(food[0][2])
print(food[1][2])
print(food[2][1])
